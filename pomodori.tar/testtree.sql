insert into deptree values
        (1, 0, '1', 'some title here', 'do whatever you want to do right now', false, 1, 20),
        (1, 0, '1', 'something depends', 'there is one thing which depends on this thing here', false, 2, 9),
        (1, 0, '1', 'another dep', 'Another dependency for another part of the project', false, 3, 4),
        (1, 0, '1', 'One leaf', 'I can start to do this right away!', false, 5, 6),
        (1, 0, '1', 'Another leaf', 'Just timple tasks, upon which everything else is based', false, 7, 8),
        (1, 0, '1', 'A big chunk', 'This is a big chunk composed of many tiny subtasks', false, 10, 19),
        (1, 0, '1', 'A medium chunk', 'Something worth remembering', false, 11, 14),
        (1, 0, '1', 'A single task', 'Something to be done concurrently', false, 12, 13),
        (1, 0, '1', 'Another single task', 'Dont ask dont tell', false, 15, 16),
        (1, 0, '1', 'Will you still love me?', 'Will you still need me? When Im 64.', false, 17, 18)
;
