#!/bin/bash

convert -delay 100 -loop 0 *.gif minute.gif
