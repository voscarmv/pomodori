#!/bin/bash

sed -i "s/('localhost', 'pomodori_user', 'tomatoes', 'pomodori')/('mysql12.000webhost.com','a7915442_pomodor','70m47035','a7915442_pomodor')/g" *.php
